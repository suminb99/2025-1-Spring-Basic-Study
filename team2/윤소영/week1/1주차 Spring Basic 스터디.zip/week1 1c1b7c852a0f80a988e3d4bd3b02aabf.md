# week1

## 라이브러리 살펴보기

- 스프링 부트 라이브러리
    - spring-boot-starter-web
        - spring-boot-starter-tomcat: 톰캣 (웹서버)
        - spring-webmvc: 스프링 웹 MVC
    - spring-boot-starter-thymeleaf: 타임리프 템플릿 엔진(View)
    - spring-boot-starter(공통): 스프링 부트 + 스프링 코어 + 로깅
        - spring-boot
            - spring-core
        - spring-boot-starter-logging

- 테스트 라이브러리
    - spring-boot-starter-test
        - junit: 테스트 프레임워크
        - mockito: 목 라이브러리
        - assertj: 테스트 코드를 좀 더 편하게 작성하게 도와주는 라이브러리
        - spring-test: 스프링 통합 테스트 지원

## View 환경 설정

- Welcome Page 만들기
    
    ```html
    <!DOCTYPE HTML>
    <html>
    <head>
    	<title>Hello</title>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    </head>
    <body>
    Hello
    <a href="/hello">hello</a>
    </body>
    </html>
    ```
    
- thymeleaf 템플릿 엔진
    
    ```java
    @Controller
    public class HelloController {
    	@GetMapping("hello")
    	public String hello(Model model) {
    		model.addAttribute("data", "hello!!");
    		return "hello";
    	}
    }
    ```
    
    ```html
    <!DOCTYPE HTML>
    <html xmlns:th="http://www.thymeleaf.org">
    <head>
    	<title>Hello</title>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    </head>
    <body>
    <p th:text="'안녕하세요. ' + ${data}" >안녕하세요. 손님</p>
    </body>
    </html>
    ```
    
- thymeleaf 템플릿 엔진 동작 확인
    
    ![image.png](image.png)
    

## 정적 컨텐츠

- 스프링 부트 정적 컨텐츠 가능
    
    ```html
    <!DOCTYPE HTML>
    <html>
    <head>
    	<title>static content</title>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    </head>
    <body>
    정적 컨텐츠입니다.
    </body>
    </html>
    ```
    
    ![정적 컨텐츠 이미지](image%201.png)
    
    정적 컨텐츠 이미지
    

## MVC와 템플릿 엔진

- MVC: Model, View, Controller
    
    ![image.png](image%202.png)
    
- Controller
    
    ```java
    @Controller
    public class HelloController {
    	@GetMapping("hello-mvc")
    	public String helloMvc(@RequestParam("name") String name, Model model) {
    		model.addAttribute("name", name);
    		return "hello-template";
    	}
    }
    ```
    
- View
    
    ```html
    <html xmlns:th="http://www.thymeleaf.org">
    <body>
    <p th:text="'hello ' + ${name}">hello! empty</p>
    </body>
    </html>
    ```
    

## API

- @ResponseBody 문자 반환
    
    ```java
    @Controller
    public class HelloController {
    	@GetMapping("hello-string")
    	@ResponseBody
    	public String helloString(@RequestParam("name") String name) {
    		return "hello " + name;
    	}
    }
    ```
    
    - `@ResponseBody` 사용하면 뷰 리졸버 (`viewResolver`) 사용하지 않음
    - 대신에 HTTP의 BODY에 문자 내용을 직접 반환 (HTML BODY TAG 말하는 것이 아님)
- @ResponseBody 객체 반환
    
    ```java
    @Controller
    public class HelloController {
    	@GetMapping("hello-api")
    	@ResponseBody
    	public Hello helloApi(@RequestParam("name") String name) {
    		Hello hello = new Hello();
    		hello.setName(name);
    		return hello;
    	}
    	static class Hello {
    		private String name;
    		public String getName() {
    			return name;
    		}
    		public void setName(String name) {
    			this.name = name;
    		}
    	}
    }
    ```
    
    - `@ResponseBody` 사용하고, 객체를 반환하면 객체가 JSON으로 변환
- @ResponseBody 사용 원리
    
    ![image.png](image%203.png)
    
    - `@ResponseBody` 사용
        - HTTP의 BODY에 문자 내용을 직접 반환
        - `viewResolver` 대신에 `HttpMessageConverter` 동작
        - 기본 문자 처리: `StringHttpMessageConverter`
        - 기본 객체 처리: `MappingJackson2HttpMessageConverter`
        - byte 처리 등 기타 여러 `HttpMessageConverter`가 기본으로 등록되어 있음