package apps.apps_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppsSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
